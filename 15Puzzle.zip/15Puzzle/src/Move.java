
public class Move {

	private Tile blank;
	private Tile targetTile;
	
	public Move(Tile blank, Tile targetTile) {
		super();
		this.blank = blank;
		this.targetTile = targetTile;
	}

	public Tile getBlank() {
		return blank;
	}

	public void setBlank(Tile blank) {
		this.blank = blank;
	}

	public Tile getTargetTile() {
		return targetTile;
	}

	public void setTargetTile(Tile targetTile) {
		this.targetTile = targetTile;
	}

	@Override
	public String toString() {
		return "Swap " + blank + " and " + targetTile;
	}
	
	
}
