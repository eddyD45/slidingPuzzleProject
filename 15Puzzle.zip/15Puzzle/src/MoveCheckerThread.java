
public class MoveCheckerThread extends Thread {
	
	private int[][] puzzle;
	private int[][] solution;
	private int blankPosX;
	private int blankPosY;
	private int oldManhattanDistance;
	private int manhattanDifference;
	Character direction;
	
	public MoveCheckerThread(SlidingPuzzleSolver slidingPuzzleSolver, Character direction) {
		puzzle = slidingPuzzleSolver.getPuzzle();
		solution = slidingPuzzleSolver.getSolution();
		blankPosX = slidingPuzzleSolver.getBlankPosX();
		blankPosY = slidingPuzzleSolver.getBlankPosY();
		oldManhattanDistance = slidingPuzzleSolver.totalManhattan();
		this.direction = direction;
	}
	
	public void run() {
		move(direction);
	}
	

	public int getManhattanDifference() {
		return manhattanDifference;
	}



	public void setManhattanDifference(int newManhattanDistance) {
		manhattanDifference = oldManhattanDistance - newManhattanDistance;
	}



	public int manhattanDistance(int posX, int posY) {
		
		for(int i = 0; i < 4; i++) {
			for (int j = 0; j < 4; j++) {
				if(solution[posX][posY] == puzzle[i][j]) {
					return (Math.abs(i - posX) + Math.abs(j - posY));
				}
			}
		}
		return 0;
		
	}
	
	public int totalManhattan() {
		int totalDistance = 0;
		for(int i = 0; i < 4; i++) {
			for (int j = 0; j < 4; j++) {
				totalDistance += manhattanDistance(i,j);
			}
		}
		
		return totalDistance;	
	}
	
	public void move(Character direction) {
		int temp = 0;
		switch(direction) {
		case 'u': temp = puzzle[blankPosX][blankPosY - 1];
				  puzzle[blankPosX][blankPosY - 1] = 0;
				  puzzle[blankPosX][blankPosY] = temp;
				  break;
		case 'd': temp = puzzle[blankPosX][blankPosY + 1];
		  		  puzzle[blankPosX][blankPosY + 1] = 0;
		  		  puzzle[blankPosX][blankPosY] = temp;
		  		  break;
		case 'l': temp = puzzle[blankPosX - 1][blankPosY];
				  puzzle[blankPosX - 1][blankPosY] = 0;
				  puzzle[blankPosX][blankPosY] = temp;
				  break;
		case 'r': temp = puzzle[blankPosX + 1][blankPosY];
				  puzzle[blankPosX + 1][blankPosY] = 0;
				  puzzle[blankPosX][blankPosY] = temp;
				  break;
		}
		
		setManhattanDifference(totalManhattan());
	}
	
	

}
