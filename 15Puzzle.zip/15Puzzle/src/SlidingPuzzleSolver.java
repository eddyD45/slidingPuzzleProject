import java.util.ArrayList;
import java.util.Stack;

public class SlidingPuzzleSolver {

	private int [][] puzzle = new int [4][4];
	private int [][] solution = new int [4][4];
	private int blankPosX;
	private int blankPosY;
	private Character[] directions = {'u','d','l','r'};
	private Stack<Move> moveHistory;
	//private Stack moveHistory;
	
	public SlidingPuzzleSolver(int [][] solution) {
		int [][] thisPuzzle = new int[4][4];
		int count = 1;
		
		for(int i = 0; i < 4; i++) {
			for (int j = 0; i < 4; i++) {
				if(i == 4 & j == 4) {
					thisPuzzle[i][j] = 0;	//blank will be considered a 0 and by default starts at position [3][3], right after 15
				}
				thisPuzzle[i][j] = count;
				count++;
			}
		}
		
		puzzle = thisPuzzle;
		this.solution = solution;
		blankPosX = 3;
		blankPosY = 3;
	}

	public int[][] getPuzzle() {
		return puzzle;
	}

	public void setPuzzle(int[][] puzzle) {
		this.puzzle = puzzle;
	}

	public int[][] getSolution() {
		return solution;
	}

	public void setSolution(int[][] solution) {
		this.solution = solution;
	}
	
	
	
	public int getBlankPosX() {
		return blankPosX;
	}

	public void setBlankPosX(int blankPosX) {
		this.blankPosX = blankPosX;
	}

	public int getBlankPosY() {
		return blankPosY;
	}

	public void setBlankPosY(int blankPosY) {
		this.blankPosY = blankPosY;
	}

	public int manhattanDistance(int posX, int posY) {
		
		for(int i = 0; i < 4; i++) {
			for (int j = 0; j < 4; j++) {
				if(solution[posX][posY] == puzzle[i][j]) {
					return (Math.abs(i - posX) + Math.abs(j - posY));
				}
			}
		}
		return 0;
		
	}
	
	public int totalManhattan() {
		int totalDistance = 0;
		for(int i = 0; i < 4; i++) {
			for (int j = 0; j < 4; j++) {
				totalDistance += manhattanDistance(i,j);
			}
		}
		
		return totalDistance;	
	}
	
	public void considerMoves() throws InterruptedException {
		ArrayList<Character> validDirections = new ArrayList<Character>();
		int maxManhattanDifference = 0;
		int whichMove = 0;
		for(int i = 0; i < directions.length; i++) {
			if(isLegal(directions[i])) {
				validDirections.add(directions[i]);
			}
		}
		
		MoveCheckerThread[] workers = new MoveCheckerThread[validDirections.size()];		//use multithreading to simultaneously check all possible moves
		for(int i = 0; i < workers.length; i++) {											//valid moves are checked for already, so only necessary threads are made, not 4 always
			workers[i] = new MoveCheckerThread(this,validDirections.get(i));
		}
		for(int i = 0; i < workers.length; i++) {
			workers[i].start();
		}
		for(int i = 0; i < workers.length; i++) {
			workers[i].join();
		}
		
		
		for(int i = 0; i < workers.length; i++) {											//once threads are done, check which has the greatest difference between the old manhattan distance
			if(workers[i].getManhattanDifference() > maxManhattanDifference) {				//and the new manhattan difference. keep track of which thread has the greatest difference. 
				maxManhattanDifference = workers[i].getManhattanDifference();				//this thread tells us which move we want to make.
				whichMove = i;
			}
		}
		
		
		
		
		
		
		
	}
	
	public void move(Character direction) {
		//check legality of move, then move left/right/up/down
	}
	
	public boolean isLegal(Character move) {
		//does moving left/right/up/down put you out of bounds?
		switch(move) {
		case 'u': if(blankPosY - 1 < 0) return false; else return true;
		case 'd': if(blankPosY + 1 > 4) return false; else return true;
		case 'l': if(blankPosX - 1 < 0) return false; else return true;
		case 'r': if(blankPosX + 1 > 4) return false; else return true;
		default: return false;
		}
	}
	
	
	
	
	
}
